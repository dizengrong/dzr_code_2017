fs_watcher
=====

An OTP application

Build
-----

    $ rebar3 compile

说明
----
1.如何确定一个文件是要从本地同步到服务器，还是要从服务器同步到本地
2.